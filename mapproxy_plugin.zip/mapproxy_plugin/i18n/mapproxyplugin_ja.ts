<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ja_JP">
<context>
    <name>message</name>
    <message>
        <location filename="mapproxy_plugin.py" line="100"/>
        <source>You need to install mapproxy first</source>
        <translation type="unfinished">最初にmapproxyをインストールしてください</translation>
    </message>
    <message>
        <location filename="mapproxy_plugin.py" line="107"/>
        <source>Are you sure you want to run mapproxy? It will run on Command Prompt.Please close it by hand when you&apos;ll stop.You can confirm the state on http://localhost:8080</source>
        <translation type="unfinished">mapproxyを実行しますか？
mapproxyはコマンドプロンプト上で実行するので、停止する際は手動で閉じてください。
起動状態は、http://localhost:8080 から確認できます。</translation>
    </message>
    <message>
        <location filename="mapproxy_plugin.py" line="111"/>
        <source>Are you sure you want to run mapproxy? You can confirm the state on http://localhost:8080</source>
        <translation type="unfinished">mapproxyを実行しますか？
起動状態は、http://localhost:8080 から確認できます。</translation>
    </message>
    <message>
        <location filename="mapproxy_plugin.py" line="138"/>
        <source>Are you sure you want to install mapproxy?So it will take a time to install, please wait for the message to appear.</source>
        <translation type="unfinished">mapproxyをインストールしますか？
インストールには少し時間がかかるので、メッセージが出るまで待ってください。</translation>
    </message>
    <message>
        <location filename="mapproxy_plugin.py" line="145"/>
        <source>mapproxy install finished</source>
        <translation type="unfinished">mapproxyのインストールが完了しました</translation>
    </message>
    <message>
        <location filename="mapproxy_plugin.py" line="148"/>
        <source>mapproxy install fail !</source>
        <translation type="unfinished">mapproxyのインストールに失敗しました</translation>
    </message>
    <message>
        <location filename="mapproxy_plugin.py" line="152"/>
        <source>Are you sure you want to remove cache?</source>
        <translation type="unfinished">キャッシュを削除しますか？</translation>
    </message>
</context>
</TS>
